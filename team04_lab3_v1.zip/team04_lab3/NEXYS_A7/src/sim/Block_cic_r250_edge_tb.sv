module Block_cic_r250_edge_tb;
    localparam integer R = 250;
    localparam integer W = 1 + 2*$clog2(R);
    localparam integer SAMPLES = 32;

    logic clk = 1'b0;
    logic pdm_ce = 1'b0;
    logic data_in = 1'b0;
    logic record_btn = 1'b0;
    logic data_out;
    logic sample_bit;
    logic [31:0] lfsr = 32'h72d4_a91b;
    logic signed [W-1:0] ref_i1 = '0, ref_i2 = '0;
    logic signed [W-1:0] ref_d1 = '0, ref_d2 = '0;
    logic signed [W-1:0] n_i1, n_i2, n_c1, n_y;
    logic signed [6:0] expected [0:SAMPLES-1];
    integer decim = 0, wr = 0, rd = 0, bit_no;
    integer scaled_pcm;

    always #5 clk = ~clk;

    Top #(.DECIMATION(R), .RECORD_SAMPLES(SAMPLES), .AUDIO_W(7)) dut (
        .clk, .pdm_ce, .data_in, .record_btn,
        .pause_on(1'b0), .speed_select(4'd0), .data_out
    );

    always @(posedge clk) begin
        if (record_btn) begin
            ref_i1 = '0; ref_i2 = '0; ref_d1 = '0; ref_d2 = '0;
            decim = 0; wr = 0;
        end else if (pdm_ce) begin
            n_i1 = ref_i1 + (data_in ? 1 : -1);
            n_i2 = ref_i2 + n_i1;
            ref_i1 = n_i1;
            ref_i2 = n_i2;
            if (decim == R-1) begin
                n_c1 = n_i2 - ref_d1;
                n_y  = n_c1 - ref_d2;
                ref_d1 = n_i2;
                ref_d2 = n_c1;
                scaled_pcm = n_y >>> 6;
                if (scaled_pcm > 63)
                    expected[wr] = 7'sd63;
                else if (scaled_pcm < -64)
                    expected[wr] = -7'sd64;
                else
                    expected[wr] = scaled_pcm;
                wr = wr + 1;
                decim = 0;
            end else begin
                decim = decim + 1;
            end
        end
        #1;
        if (dut.mem_we) begin
            if ((rd >= wr) || (dut.mem_wdata !== expected[rd]))
                $fatal(1, "block CIC mismatch sample %0d: expected=%0d actual=%0d",
                       rd, expected[rd], dut.mem_wdata);
            rd = rd + 1;
        end
    end

    initial begin
        @(negedge clk); record_btn = 1'b1;
        @(negedge clk); record_btn = 1'b0;
        for (bit_no = 0; bit_no < R*SAMPLES; bit_no = bit_no + 1) begin
            repeat (31) @(negedge clk);
            sample_bit = lfsr[0];
            lfsr = {lfsr[0] ^ lfsr[1] ^ lfsr[21] ^ lfsr[31], lfsr[31:1]};
            data_in = sample_bit;
            pdm_ce = 1'b1;
            @(negedge clk);
            // Model M_DATA changing immediately after the sampling edge.
            pdm_ce = 1'b0;
            data_in = ~sample_bit;
        end
        repeat (8) @(negedge clk);
        if ((wr != SAMPLES) || (rd != SAMPLES))
            $fatal(1, "sample count mismatch reference=%0d block=%0d", wr, rd);
        $display("PASS: fixed block CIC2 matches conventional CIC2 at R=%0d with post-edge M_DATA changes", R);
        $finish;
    end
endmodule
