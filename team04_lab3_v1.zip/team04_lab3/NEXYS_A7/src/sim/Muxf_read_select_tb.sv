module Muxf_read_select_tb;
    logic clk = 1'b0;
    logic data_out;
    integer bank;
    integer bit_no;

    always #5 clk = ~clk;

    Top dut (
        .clk(clk), .pdm_ce(1'b0), .data_in(1'b0),
        .record_btn(1'b0), .pause_on(1'b0), .speed_select(4'd0),
        .data_out(data_out)
    );

    initial begin
        // Isolate the combinational selector from BRAM contents.  Every bank
        // receives a distinct signed 7-bit pattern, then each legal bank index
        // must propagate bit-exactly through the explicit MUXF7 path.
        // Force each complete bank output variable.  XSIM 2026.1 rejects a
        // force on an unpacked-array element at the parent connection.
        force dut.gen_audio_bank[0].bank.data_out = 7'sh01;
        force dut.gen_audio_bank[1].bank.data_out = 7'sh12;
        force dut.gen_audio_bank[2].bank.data_out = 7'sh23;
        force dut.gen_audio_bank[3].bank.data_out = 7'sh34;
        force dut.gen_audio_bank[4].bank.data_out = 7'sh45;
        force dut.gen_audio_bank[5].bank.data_out = 7'sh56;
        force dut.gen_audio_bank[6].bank.data_out = 7'sh67;

        for (bank = 0; bank < 7; bank = bank + 1) begin
            force dut.mem_addr = bank << 15;
            #1;
            if (dut.mem_rdata !== dut.bank_dout[bank])
                $fatal(1, "read mux mismatch bank=%0d expected=%0h actual=%0h",
                       bank, dut.bank_dout[bank], dut.mem_rdata);
        end

        $display("PASS: explicit MUXF7 seven-bank read selector");
        $finish;
    end
endmodule
