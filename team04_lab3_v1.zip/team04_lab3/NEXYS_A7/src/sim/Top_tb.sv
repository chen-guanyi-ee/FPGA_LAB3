module Top_tb;
    logic clk = 1'b0;
    logic pdm_ce = 1'b0;
    logic data_in = 1'b0;
    logic record_btn = 1'b0;
    logic pause_on = 1'b0;
    logic [3:0] speed_select = 4'd0;
    logic data_out;
    logic [2:0] paused_addr;

    always #5 clk = ~clk;

    Top #(
        .DECIMATION(4),
        .RECORD_SAMPLES(8),
        .AUDIO_W(4)
    ) dut (
        .clk(clk), .pdm_ce(pdm_ce), .data_in(data_in),
        .record_btn(record_btn), .pause_on(pause_on),
        .speed_select(speed_select),
        .data_out(data_out)
    );

    task automatic pulse_button(ref logic button);
        @(negedge clk); button = 1'b1;
        @(negedge clk); button = 1'b0;
        @(posedge clk); #1;
    endtask

    initial begin
        for (int mode = 0; mode < 15; mode++) begin
            @(negedge clk); speed_select = mode[3:0];
            #1;
            if (dut.speed_mode != mode[3:0])
                $fatal(1, "direct speed code mismatch mode=%0d actual=%0d",
                       mode, dut.speed_mode);
        end
        @(negedge clk); speed_select = 4'hf;
        #1;
        if (dut.speed_mode != 4'd0)
            $fatal(1, "reserved speed code did not map to safe 1x");
        @(negedge clk); speed_select = 4'd0;

        pulse_button(record_btn);

        // Eight PCM samples, each formed from four alternating PDM bits.
        repeat (32) begin
            @(negedge clk);
            data_in = ~data_in;
            pdm_ce = 1'b1;
            @(negedge clk);
            pdm_ce = 1'b0;
            repeat (3) @(negedge clk);
        end

        wait (dut.state == 2'd3);
        @(negedge clk); speed_select = 4'd1;
        @(posedge clk); #1;
        if (dut.speed_mode != 4'd1)
            $fatal(1, "speed code did not select 2x");

        @(negedge clk); pause_on = 1'b1;
        paused_addr = dut.sample_addr;
        repeat (8) begin
            @(negedge clk); pdm_ce = 1'b1;
            @(negedge clk); pdm_ce = 1'b0;
        end
        if (dut.state != 2'd3)
            $fatal(1, "pause switch changed playback state");
        if (dut.sample_addr != paused_addr)
            $fatal(1, "pause switch did not hold playback address");
        @(negedge clk); pause_on = 1'b0;

        $display("PASS: record, auto-play, speed, pause, resume");
        $finish;
    end
endmodule
