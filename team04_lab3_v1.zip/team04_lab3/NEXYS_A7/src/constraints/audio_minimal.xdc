set_property -dict { PACKAGE_PIN E3  IOSTANDARD LVCMOS33 } [get_ports CLK100MHZ]
create_clock -add -name sys_clk_pin -period 10.000 -waveform {0.000 5.000} [get_ports CLK100MHZ]

set_property -dict { PACKAGE_PIN J15 IOSTANDARD LVCMOS33 } [get_ports {SW[0]}]
set_property -dict { PACKAGE_PIN L16 IOSTANDARD LVCMOS33 } [get_ports {SW[1]}]
set_property -dict { PACKAGE_PIN M13 IOSTANDARD LVCMOS33 } [get_ports {SW[2]}]
set_property -dict { PACKAGE_PIN R15 IOSTANDARD LVCMOS33 } [get_ports {SW[3]}]
set_property -dict { PACKAGE_PIN R17 IOSTANDARD LVCMOS33 } [get_ports {SW[4]}]
set_property -dict { PACKAGE_PIN T18 IOSTANDARD LVCMOS33 } [get_ports {SW[5]}]

set_property -dict { PACKAGE_PIN J5  IOSTANDARD LVCMOS33 } [get_ports M_CLK]
set_property -dict { PACKAGE_PIN H5  IOSTANDARD LVCMOS33 } [get_ports M_DATA]
set_property -dict { PACKAGE_PIN F5  IOSTANDARD LVCMOS33 } [get_ports M_LRSEL]
set_property -dict { PACKAGE_PIN A11 IOSTANDARD LVCMOS33 } [get_ports AUD_PWM]
set_property -dict { PACKAGE_PIN D12 IOSTANDARD LVCMOS33 } [get_ports AUD_SD]

set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
