# Recreate NEXYS_A7.xpr and run synthesis, implementation and bitstream.
# Usage (from this folder):
#   vivado -mode batch -source create_project.tcl
# Settings: AreaOptimized_high synthesis with control_set_opt_threshold 4
# (smallest of thresholds 1/4/8/16/auto), opt_design ExploreArea,
# phys_opt_design off, route_design Explore.

set root [file normalize [file dirname [info script]]]
cd $root

create_project NEXYS_A7 $root -part xc7a100tcsg324-1 -force

add_files -norecurse [list \
    [file join $root src rtl NEXYS_A7.sv] \
    [file join $root src rtl Top_block_form_fixed.sv]]
set_property file_type SystemVerilog [get_files *.sv]
set_property top NEXYS_A7 [get_filesets sources_1]

add_files -fileset constrs_1 -norecurse [file join $root src constraints audio_minimal.xdc]

add_files -fileset sim_1 -norecurse [list \
    [file join $root src sim Top_tb.sv] \
    [file join $root src sim Block_cic_r250_edge_tb.sv] \
    [file join $root src sim Muxf_read_select_tb.sv]]
set_property file_type SystemVerilog [get_files -of_objects [get_filesets sim_1] *.sv]
set_property top Top_tb [get_filesets sim_1]
set_property top_auto_set 0 [get_filesets sim_1]

set_property strategy Flow_AreaOptimized_high [get_runs synth_1]
set_property STEPS.SYNTH_DESIGN.ARGS.DIRECTIVE AreaOptimized_high [get_runs synth_1]
set_property STEPS.SYNTH_DESIGN.ARGS.CONTROL_SET_OPT_THRESHOLD 4 [get_runs synth_1]

set_property STEPS.OPT_DESIGN.ARGS.DIRECTIVE ExploreArea [get_runs impl_1]
set_property STEPS.PLACE_DESIGN.ARGS.DIRECTIVE Default [get_runs impl_1]
set_property STEPS.PHYS_OPT_DESIGN.IS_ENABLED false [get_runs impl_1]
set_property STEPS.ROUTE_DESIGN.ARGS.DIRECTIVE Explore [get_runs impl_1]

if {![info exists ::env(NO_RUN)]} {
    launch_runs synth_1 -jobs 4
    wait_on_run synth_1
    launch_runs impl_1 -to_step write_bitstream -jobs 4
    wait_on_run impl_1
    open_run impl_1
    report_utilization -file [file join $root post_route_utilization.rpt]
    report_timing_summary -max_paths 10 -file [file join $root post_route_timing.rpt]
    report_drc -file [file join $root post_route_drc.rpt]
}
