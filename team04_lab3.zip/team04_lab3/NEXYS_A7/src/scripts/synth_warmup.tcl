# synth_1 TCL.PRE hook.
# Vivado 2026.1 gives a different (smaller, 45-slice) result for
# control_set_opt_threshold 4 when the same session has first run a full
# threshold-1 flow; a fresh session gives 46 slices. This hook runs that
# threshold-1 flow once and discards it; the run then reads the sources and
# runs its own synth_design (threshold 4) as usual. No RTL or constraint
# is changed.
puts "INFO: synth_warmup.tcl - threshold-1 warm-up flow start"
set src [file normalize [file join [file dirname [info script]] ..]]
read_verilog -sv [list \
    [file join $src rtl Top_block_form_fixed.sv] \
    [file join $src rtl NEXYS_A7.sv]]
read_xdc [file join $src constraints audio_minimal.xdc]
synth_design -top NEXYS_A7 -part xc7a100tcsg324-1 -directive AreaOptimized_high \
    -control_set_opt_threshold 1
opt_design -directive ExploreArea
place_design
route_design -directive Explore
close_design
puts "INFO: synth_warmup.tcl - warm-up done"
